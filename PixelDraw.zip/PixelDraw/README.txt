This product, requires PYTHON 3.7.3 or above versions for proper functionality, please go to python.org to download PYTHON,
this will also require the TKinter Library installed.